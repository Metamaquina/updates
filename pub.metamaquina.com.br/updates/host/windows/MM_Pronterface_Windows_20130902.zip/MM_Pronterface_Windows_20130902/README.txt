Pronterface 20130628 by Metamaquina <http://www.metamaquina.com.br/>

This is 100% free software (software that respects users' freedom).
This is a binary distribution for Windows.
You can get the corresponding source code at https://github.com/Metamaquina/Printrun/tree/MM_20130628

Avrdude, libusb and Slic3r source code is available from their respective upstream code repositories.

